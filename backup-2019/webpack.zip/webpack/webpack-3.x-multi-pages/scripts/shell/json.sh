#!/bin/bash

## #!/usr/bin/env node

# echo "^-v-^ JSON DB is running in development env!" && npm run db

echo "^-v-^ JSON DB is running in development env!" && nodemon -w ./server.js localhost 8888


