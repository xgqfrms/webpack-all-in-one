import "../css/main.css";

console.log(`this is main.js!`);


