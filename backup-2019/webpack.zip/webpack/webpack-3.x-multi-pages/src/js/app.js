import "../css/app.css";

console.log(`this is app.js!`);
