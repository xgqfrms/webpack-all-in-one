"use strict";

/**
 * @author xgqfrms
 * @license MIT
 * @copyright gildata
 *
 * @description FramewokeConfigsInit framework-configs-init.js
 *
 */

 // utils
import {$qsa} from "../utils/html-document-select";

import { getDatas } from "../utils/fetch-ajax";
import { FetchIP  } from "../utils/urls";

/**
 *获取用户信息
 * @returns {{name: string, id: string}}
 */
const getUser = ()=>{
    return {
      "name": "admin",
      "id": "01"
    };
};
const getStorage = (name = '')=>{
    if(name === ''){
        return null;
    }
    if(!window.sessionStorage){
        console.log("浏览器不支持sessionStorage");
        getDatas(FetchIP + '/' + name).then(
            (json) => {
                return json;
            }
        ).catch(err => console.log(`fetch error`, err));
    }else{
       let result = window.sessionStorage.getItem(name);
        if(result === undefined){
            getDatas(FetchIP + '/' + name).then(
                (json) => {
                    return json;
                }
            ).catch(err => console.log(`fetch error`, err));
        }else{

        }
    }
};
const getConfig  = (url = '')=>{
    url = (url === "") ? FetchIP : url;
};

const FrameworkConfigsInit = (url = ``, debug = false) => {
    let uids = [...$qsa(`[data-icon-uid*="module-"]`)];
    url = (url === "") ? FetchIP : url;
    getDatas(url).then(
        (json) => {
            localStorage.removeItem(`configs`);
            localStorage.setItem(`configs`, JSON.stringify(json));
            sessionStorage.removeItem(`configs`);
            sessionStorage.setItem(`configs`, JSON.stringify(json));
            uids.forEach(
                (item, i) => {
                    let uid = item.dataset.name;
                    if (uid) {
                        // console.log(`module uid ${i + 1} =\n`, uid, item);
                        json.forEach(
                            (module) => {
                                if (module.uid === uid) {
                                    let {
                                        configs,
                                        size
                                    } = module;
                                    item.dataset.configs = configs;
                                    item.title = size;
                                }
                            }
                        );
                    }
                }
            );
        }
    ).catch(err => console.log(`fetch error`, err));
    // return result;
};

export default FrameworkConfigsInit;

export {
    FrameworkConfigsInit
};
