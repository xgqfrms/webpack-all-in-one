'use strict';

import {$qs,$qsa} from "../utils/html-document-select";

const modulesLoader = {
    dragStart: function(e) {
        let uid = e.target.dataset.iconUid.substr(12);
        let configs = ``;
        //加载配置文件
        e.dataTransfer.effectAllowed = `move`;
        e.target.style.opacity = "1";
        e.dataTransfer.setData("text/plain", `${uid},${configs}`);
    },
    dragEnd: function(e) {
        e.preventDefault();
    },
    dragEnter: function(e) {
        e.preventDefault();
        this.classList.add(`test-border`);
        return true;
    },
    dragOver: function(e) {
        e.preventDefault();
        return true;
    },
    dragLeave: function(e) {
        e.preventDefault();
        this.classList.remove(`test-border`);
        return true;
    },
    drop: function(e) {
        e.preventDefault();
        e.stopPropagation();
        this.classList.remove(`test-border`);
        let that = this;
        let dataStr = e.dataTransfer.getData("text/plain");
        let regex = /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uff66-\uff9f]/igm;
        if (regex.test(dataStr)) {
            console.warn(`uid is invalid!`, dataStr.length);
        } else {
            let uid = e.dataTransfer.getData("text/plain").split(",")[0],
                configs = e.dataTransfer.getData("text/plain").split(",")[1],
                configsObj = {};
            if (emptyChecker(configs)) {
                configsObj = getB64Object(configs);
                console.log(`new configsObj =`, configsObj);
            }
            let module_exist_checker = ``;
            if (typeof(uid) === "string" && uid.length < 100 && !uid.includes("☰")) {
                module_exist_checker = document.querySelector(`[data-modules-container="${uid}"]`);
                let box = document.querySelector(`#left-sortable-container`);
                box.classList.remove(`over-border`);
                console.log(`module_exist_checker =`, module_exist_checker, uid);
            }else{
                // invalid value
            }
            if (module_exist_checker === null) {
                if (!uid.includes("bondratefast")) {
                    if (!uid.includes("-width")) {
                        FrameworkOptionsLoader(uid);
                        showContent(that, uid, configsObj);
                    } else {
                        // showContainer(uid, configsObj);
                        swal({
                            title: "容器只能拖放到布局中!",
                            text: `
                                        请先拖放容器到布局，再拖放模块!\n
                                        1 秒后自动关闭.
                                    `,
                            icon: "warning",
                            className: "warning-alert-style",
                            timer: 2000,
                            button: {
                                text: "关闭",
                                value: true,
                                visible: true,
                                closeModal: true
                            }
                        });
                    }
                } else {
                    console.warn(`${uid} is not exist in the \`HTML import link\`!`);
                    swal({
                        title: "此模块不存在!",
                        text: `
                                    此模块组件还在开发中!\n 1 秒后自动关闭.
                                `,
                        icon: "warning",
                        // className: "warning-alert-style",
                        timer: 2000,
                        button: {
                            text: "关闭",
                            value: true,
                            visible: true,
                            closeModal: true
                        }
                    });
                    if (debug) {
                        throw new Error(`Uncaught TypeError: Cannot read property 'import' of null! ??? module_uid = ${uid} ???`);
                    }
                }
            }else{
                try {
                    if (module_exist_checker === `` & uid.length > 14) {
                        // console.log("bug , 此模块已存在!");
                    }else{
                        if (uid) {
                            swal({
                                title: "此模块已存在!",
                                text: `
                                            此模块已存在, 不能再次拖放!\n
                                            1 秒后自动关闭.
                                        `,
                                icon: "warning",
                                className: "warning-alert-style",
                                timer: 2000,
                                button: {
                                    text: "关闭",
                                    value: true,
                                    visible: true,
                                    closeModal: true
                                }
                            });
                        } else {
                            console.log(`uid = `, uid, typeof(uid), uid.length);
                        }
                    }
                } catch (error) {
                    console.log(`%c Sorry, some errors occurred!`, `color: #f0f`);
                }
            }
        }
    },
    binding: function () {  //为容器(目标区域)绑定事件
        //查找容器
        let module_containers = [...$qsa(`[data-container*="containers"]`)];
        if(module_containers && module_containers.length) {
            module_containers.forEach(
                (container, i) => {
                    container.addEventListener(`dragenter`, this.dragEnter, false);
                    container.addEventListener(`dragover`, this.dragOver, false);
                    container.addEventListener(`dragleave`, this.dragLeave, false);
                    container.addEventListener(`drop`, this.drop, false);// capture
                }
            );
        }
    },
    init: function() {
        let modules = $qsa(`[data-icon-uid*="module-data"]`);
        for (let i = 0; i < modules.length; i++) {     //为拖拽区域绑定事件
            modules[i].addEventListener(`dragstart`, this.dragStart, false);
        }
        this.binding();
    }
};

export default modulesLoader;
export {
    modulesLoader
};