"use strict";

const  loadTemplates = {
    loadTemplate: (uid = "",url = ``)=>{
        if(uid === ""){
            console.error("加载的模板uid是空值");
            return false;
        }
        let templateBox = document.querySelector(`[data-modules="modules-container"]`), links = ``;
        if(!templateBox.querySelector(`[data-rel="${uid}"]`)) {
            links = `<link rel="import" href="${url}.html" data-rel="${uid}">`;
            templateBox.insertAdjacentHTML(`afterbegin`, links);
            let link = document.querySelector(`link[data-rel="${uid}"]`);
            link.onload = templateBox.readystatechange = ()=>{
                let  template = link ? link.import : null,
                    div = template ? template.querySelector(`[data-div="templates-${uid}"]`) : null;
                console.log(div)
                if(div) {
                    document.querySelector(`[data-template="template-container"`).appendChild(div);
                }
            };
        }
    },
    loadTemplateCloneDom: (uid)=>{

    }
};

export default loadTemplates;
export {
    loadTemplates
};