'use strict'

import './sortable';
import './sweetalert.min';