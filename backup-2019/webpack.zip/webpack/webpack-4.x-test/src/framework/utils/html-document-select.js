"use strict";

/**
 * @author xgqfrms
 * @description
 */
var $ = $ || {};
$.DOM_queryAll = ((str = `[data-sortable-box*="sortable-box"]`, debug = false) => {
    let results = document.querySelectorAll(str);
    if (debug) {
        if (results) {
            console.log(`result = `, results);
        }else{
            console.log(`Error: result = `, results);
        }
    }
    return results ? results : ``;
});

$.DOM_query = ((str = `[data-sortable-box*="sortable-box"]`, debug = false) => {
    let result = document.querySelector(str);
    if (debug) {
        if (result) {
            console.log(`result = `, result);
        }else{
            console.log(`Error: result = `, result);
        }
    }
    return result ? result : ``;
});

export default $;
const DOM_queryAll = $.DOM_queryAll;
const DOM_query = $.DOM_query;

export {
    DOM_query,
    DOM_queryAll,
    DOM_query as $qs,
    DOM_queryAll as $qsa
};


/*

// import $ from "jquery";

import {$qsa, $qs} from "../utils/no-need-jquery";

import { $qsa, $qs } from "../utils/no-need-jquery";

import {
    $qsa,
    $qs
} from "../utils/no-need-jquery";


import {
    DOM_query,
    DOM_queryAll,
} from "../utils/no-need-jquery";


import {
    DOM_query,
    DOM_queryAll,
    $qs,
    $qsa
} from "../utils/no-need-jquery";

*/
