"use strict";

/**
 *
 * @author xgqfrms
 * @license MIT
 * @description Fetch & Ajax
 */

import "whatwg-fetch";

const fetchImage = (url = ``) => {
    return fetch(url)
        .then(res => res.blob())
        .then(
            (blob) => {
                return blob;
            }
        ).catch(err => console.log(`fetch image error`, err));
};

const fetchJSON = (url = ``) => {
    return fetch(
        url,
        {
            method: "GET",
            // mode: "no-cors",
            mode: "cors",
            headers: {
                // "Content-Type": "application/x-www-form-urlencoded",
                // "Content-Type": "application/json",
                "Content-Type": "application/json; charset=utf-8",
            },
        })
        .then(res => res.json())
        .then(
            (json) => {
                return json;
            }
        )
        .catch(err => console.log(`fetch error`, err));
};

// async / await
async function getDatas(url = ``) {
    try {
        return await fetchJSON(url);
    } catch (err) {
        console.error("getDatas error:\n", err);
    }
}


const fetchPOSTJSON = (url = ``, obj = {}) => {
    return fetch(url,
        {
            method: "POST",
            mode: "cors",
            headers: {
                "Content-Type": "application/json; charset=utf-8",
            },
            body: JSON.stringify(obj),
        }).then(res => res.json())
        .then(
            (json) => {
                console.log(`POST configs OK!`);
                return json;
            }
        ).catch(err => console.log(`fetch error & POST configs Error!`, err));
};

// async / await
async function getPOSTDatas(url = ``, obj = {}) {
    try {
        return await fetchJSON(url, obj);
    } catch (err) {
        console.error("getDatas error:\n", err);
    }
}

const queryStringGenerator = (obj = {}) => {
    let result = ``,
        keys = Object.keys(obj),
        values = Object.values(obj),
        keysLength = Object.keys(obj).length;
    keys.forEach(
        (key, i) => {
            if (i < ( keysLength - 1)) {
                if (typeof(values[i]) === "object") {
                    result += `${key}=${JSON.stringify(values[i])}&`;
                } else {
                    result += `${key}=${values[i]}&`;
                }
            } else {
                if (typeof(values[i]) === "object") {
                    result += `${key}=${JSON.stringify(values[i])}`;
                } else {
                    result += `${key}=${values[i]}`;
                }
            }
        }
    );
    return result;
};

const fetchPOSTForm = (url = ``, obj = {}) => {
    let queryString = ``;
    queryString = queryStringGenerator(obj);
    return fetch(url,
        {
            method: "POST",
            mode: "cors",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: queryString,
        }).then(res => res.json())
        .then(
            (json) => {
                return json;
            }
        ).catch(err => console.log(`fetch error`, err));
};



const fetchAjax = {
    fetchJSON,
    getDatas,
    fetchPOSTJSON,
    getPOSTDatas,
    queryStringGenerator,
    fetchPOSTForm,
    fetchImage
};

export default fetchAjax;

export {
    fetchJSON,
    getDatas,
    fetchPOSTJSON,
    getPOSTDatas,
    queryStringGenerator,
    fetchPOSTForm,
    fetchAjax,
    fetchImage
};
