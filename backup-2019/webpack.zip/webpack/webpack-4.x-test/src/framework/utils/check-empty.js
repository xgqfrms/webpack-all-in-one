"use strict";

/**
 * @copyright gildata
 * @description Utils & emptyChcker();
 * @param {String} key
 */

const emptyChecker = (key = ``) => {
    let result = true,
        strKey = `${key}`;
    switch (strKey) {
        case "undefined":
            result = false;
            break;
        case "null":
            result = false;
            break;
        case "":
            result = false;
            break;
        case "--":
            result = false;
            break;
        case -1.7976931348623157e+308:  //这个不清楚
            result = false;
            break;
        default:
            break;
    }
    if (process.env.NODE_ENV === 'development') {
        console.log(`key =`, key);
        console.log(`strKey =`, strKey);
        console.log(`result =`, result);
    }
    return result;
};


export default emptyChecker;

export {
    emptyChecker
};
