"use strict";

/**
 * @license MIT
 * @copyright gildata
 * @description  URL configs & getURl & search params
 * @example
 *
 */

window.ORIGIN_IP = window.ORIGIN_IP || window.parent.location.origin;

const FetchIP = window.ORIGIN_IP.includes("http://localhost") || window.ORIGIN_IP.includes("file://") || window.ORIGIN_IP.includes("3000") || window.ORIGIN_IP.includes("3001") || window.ORIGIN_IP.includes("3002")
    ? "http://10.1.5.202"
    : `${window.ORIGIN_IP}`;

const getUrls = () => {
    let URL = window.IP || window.parent.location.href,
        PROTOCOL = window.PROTOCOL || window.parent.location.protocol,
        HOST = window.HOST || window.parent.location.host,
        PORT = window.PORT || window.parent.location.port,
        SEARCH = window.SEARCH || window.parent.location.search,
        HASH = window.HASH || window.parent.location.hash,
        ORIGIN = window.ORIGIN || window.parent.location.origin;
    // query object
    SEARCH = JSON.parse(decodeURI(SEARCH).substr(1));
    return {
        // IP,
        URL,
        PROTOCOL,
        HOST,
        PORT,
        SEARCH,
        HASH,
        ORIGIN
    };
};
const SearchParams = (search = ``, debug = false) => {
    let params = "";
    if (search) {
        params = new URLSearchParams(search);
    } else {
        // default search
        search = decodeURIComponent(window.location.search);
        params = new URLSearchParams(search);
    }
    let result = {};
    for (let param of params) {
        let key = ``,
            value = ``;
        key = param[0];
        value = param[1];
        result[key] = value;
    }
    return result;
};
export default FetchIP;

export {
    FetchIP,
    getUrls,
    SearchParams
};
