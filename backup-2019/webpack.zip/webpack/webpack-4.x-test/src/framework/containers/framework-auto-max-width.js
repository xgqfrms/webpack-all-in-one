"use strict";

/**
 *
 * @author xgqfrms
 * @license MIT
 * @description FrameworkAutoMaxWidth
 */

const FrameworkAutoMaxWidth = (datas = [], debug = false) => {
    let result = ``;
    // do something...
    return result;
};

const autoSettingMaxWidth = (debug = false) => {
    window.canvasRuler.api.destroy();
    // bug
    window.canvasRuler = new ruler({
        container: document.querySelector(`#rulerwrapper`),
        rulerHeight: 18,
        fontFamily: 'arial',
        fontSize: '7px',
        strokeStyle: 'black',
        lineWidth: 1,
        // enableMouseTracking: false,
        // enableToolTip: false,
    });
    let box = document.querySelector(`#left-sortable-container`),
        wrapper = document.querySelector(`#rulerwrapper`);
    let width = parseInt(box.clientWidth, 10) || 0;
    wrapper.style.width = `${width}px`;
    if (width > 1200) {
        // 1320
        let inputs = [...document.querySelectorAll(`[data-type="type-container-input"]`)];
        inputs.forEach(
            (input, i) => {
                input.max = (width - 10);
                input.value = (width - 10);
            }
        );
    } else {
        // 1310
        let inputs = [...document.querySelectorAll(`[data-type="type-container-input"]`)];
        inputs.forEach(
            (input, i) => {
                // 1110
                input.max = (width - 10);
                input.value = (width - 10);
            }
        );
    }
};


export default FrameworkAutoMaxWidth;

export {
    FrameworkAutoMaxWidth,
    autoSettingMaxWidth
};
