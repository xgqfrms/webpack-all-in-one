"use strict";

/**
 * @copyright gildata
 *
 * @description FrameworkShowContainer
 *
 */

import {$qs} from "../utils/html-document-select";

import { sortModules } from "./framework-sort-handler";

import { deleteContainer } from "./framework-delete-container";
import { containerSettings } from "./framework-container-settings";
import { autoSettingMaxWidth } from "./framework-auto-max-width";

const FrameworkShowContainer = (that = ``, uid = ``, options = {}) => {
    if (uid) {
        let temp = $qs(`[data-template="template-containers-${uid}"]`),
            clone = temp ? temp.content.cloneNode(true) : null;
        if(process.env.NODE_ENV === "development"){
            console.log(`clone: ${clone}`,`that: ${that}`);
        }
        if (clone && that) {
            that.appendChild(clone);
            setTimeout(() => {
                // sortContainers();
                sortModules();
                // modulesLoader.binding();
                deleteContainer();
                containerSettings();
                setTimeout(() => {
                    autoSettingMaxWidth();
                }, 0);
            }, 0);
        } else {
            console.error(`%c show container uid error!`, `color: #f0f`, uid);
            swal({
                title: "容器不存在!",
                text: `
                容器还在开发中!\n
                1 秒后自动关闭.
            `,
                icon: "warning",
                className: "warning-alert-style",
                timer: 2000,
                button: {
                    text: "关闭",
                    value: true,
                    visible: true,
                    closeModal: true
                }
            });
        }
    } else {
        console.error(`uid can not be find!`, uid);
    }
};

export default FrameworkShowContainer;

export {
    FrameworkShowContainer,
    FrameworkShowContainer as showContainer
};
