"use strict";

/**
 *
 * @author xgqfrms
 * @copyright gildata
 *
 * @description FrameworkDeleteContainer
 */

import {$qsa} from "../utils/html-document-select";


const FrameworkDeleteContainer = () => {
    let targets = [...$qsa(`[data-container-delete-btn="delete-container"]`)];
    targets.forEach(
        (target, i) => {
            let deleteFlag = target.dataset.containerDeleteFlag;
            if (!deleteFlag) {
                target.dataset.containerDeleteFlag = "true";
                target.addEventListener(`click`, function(e) {
                    let that = this.parentNode.parentElement;
                    swal({
                        title: "你确定要删除此容器?",
                        icon: "error",
                        buttons: {
                            ok: {
                                text: "确定",
                                value: "ok",
                                visible: true,
                                className: "",
                                closeModal: true
                            },
                            cancel: {
                                text: "取消",
                                value: "cancel",
                                visible: true,
                                className: ""
                            }
                        }
                    }).then(
                        (value) => {
                            if(value === "ok"){
                                // this
                                that.remove();
                                swal({
                                    title: "已删除此容器",
                                    text: "1秒后自动关闭",
                                    icon: "success",
                                    buttons: false,
                                    timer: 1000
                                });
                            }else{
                                swal({
                                    title: "已取消删除此容器!",
                                    text: "1秒后自动关闭",
                                    icon: "success",
                                    buttons: false,
                                    timer: 1000
                                });
                            }
                        }
                    );
                });
            }
        }
    );
};
export default FrameworkDeleteContainer;

export {
    FrameworkDeleteContainer,
    FrameworkDeleteContainer as deleteContainer
};
