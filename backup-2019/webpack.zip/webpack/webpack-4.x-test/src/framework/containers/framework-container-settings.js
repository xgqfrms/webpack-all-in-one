"use strict";

/**
 *
 * @author xgqfrms
 * @license MIT
 * @description FrameworkContainerSettings
 *
 */

import {$qsa} from "../utils/html-document-select";


const FrameworkContainerSettings = (debug = false) => {
    let configs = [...$qsa(`[data-container-config-btn="config-container"]`)];
    configs.forEach(
        (config, i) => {
            let openFlag = config.dataset.containerOpenFlag;
            if (!openFlag) {
                config.dataset.containerOpenFlag = "true";
                config.addEventListener(`click`, function(e) {
                    // e.target === this
                    let that = this;
                    let container = that.parentElement.parentElement;
                    let save = that.querySelector(`[data-btn="container-save"]`);
                    let saveFlag = save.dataset.containerSaveFlag;
                    if (!saveFlag) {
                        config.dataset.containerSaveFlag = "true";
                        save.addEventListener(`click`, function(e) {
                            let height = "",
                                width = "";
                            let inputs = [...this.parentElement.previousElementSibling.querySelectorAll(`[data-type="type-container-input"]`)];
                            inputs.forEach(
                                (input, i) => {
                                    let key = input.dataset.key,
                                        value = input.value;
                                    switch (key) {
                                        case "key-width":
                                            width = value;
                                            container.style.width = `${width}px`;
                                            break;
                                        case "key-height":
                                            height = value;
                                            container.style.height = `${height}px`;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            );
                            setTimeout(() => {
                                that.firstElementChild.classList.remove(`f10_settings_options-box-open`);
                                that.firstElementChild.classList.add(`f10_settings_options-box-close`);
                            }, 0);
                        });
                    }
                    let modals = document.querySelectorAll(`[data-configs="f10-options-box"]`);
                    modals.forEach(
                        (modal, i) => {
                            // modal
                            if (modal.classList.contains(`f10_settings_options-box-open`)) {
                                modal.classList.remove(`f10_settings_options-box-open`);
                            }
                        }
                    );
                    let spanUid = e.target.dataset.containerConfigBtn;
                    if (spanUid === "config-container") {
                        this.firstElementChild.classList.toggle(`f10_settings_options-box-close`);
                        this.firstElementChild.classList.toggle(`f10_settings_options-box-open`);
                        let others = [...$qsa(`[data-container-config-btn="config-container"]`)];
                        others.forEach(
                            (other, i) => {
                                if (other !== this) {
                                    // toggle
                                    other.firstElementChild.classList.add(`f10_settings_options-box-close`);
                                    other.firstElementChild.classList.remove(`f10_settings_options-box-open`);
                                } else {
                                    // console.log(`other === this =`, this, other);
                                }
                            }
                        );
                    } else {
                        // stop bubble & capture
                    }
                });
            } else {
                // in case duplication binding
            }
        }
    );
};

export default FrameworkContainerSettings;

export {
    FrameworkContainerSettings,
    FrameworkContainerSettings as containerSettings
};
