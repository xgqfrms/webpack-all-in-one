"use strict";

/**
 * @copyright gildata
 * @description ContainerLoaders
 */
import {$qs, $qsa} from "../utils/html-document-select";
import { emptyChecker } from "../utils/check-empty";
import { showContainer } from "./framework-show-container";
import { sortContainers } from "./framework-sort-handler";
import {loadTemplates} from "../modules/framework-loader-templates";

const containersLoader = {
        dragStart: function(e) {
            let uid = e.target.dataset.iconUid.substr(15),
                configs = e.target.dataset.configs;
            e.dataTransfer.effectAllowed = `move`;
            e.target.style.opacity = "1";
            let dataStr = `${uid},${configs}`;
            e.dataTransfer.setData("text/plain", dataStr);
            loadTemplates.loadTemplate(uid,"../templates/containers");
        },
        dragEnd: function(e) {
            e.preventDefault();
            // e.stopPropagation();
            return true;
        },
        dragEnter: function(e) {
            e.preventDefault();
            this.classList.add(`over-border`);
            return true;
        },
        dragOver: function(e) {
            e.preventDefault();
            return true;
        },
        dragLeave: function(e) {
            e.preventDefault();
            this.classList.remove(`over-border`);
            return true;
        },
        drop: function(e) {
            e.preventDefault();
            e.stopPropagation();
            let that = this;
            this.classList.remove(`over-border`);
            let dataStr = e.dataTransfer.getData("text/plain");
            let regex = /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uff66-\uff9f]/igm;
            if (regex.test(dataStr)) {
                console.warn(`uid is invalid!`, dataStr.length);
            } else {
                let uid = dataStr.split(",")[0],
                    configs = dataStr.split(",")[1],
                    configsObj = {};
                if (emptyChecker(configs)) {
                    Object.assign(configsObj, JSON.parse(decodeURIComponent(atob(configs))));
                }
                if (typeof(uid) === "string" && uid.length) {
                    try {
                        // Container
                        if (uid.includes(`-width`)) {
                            console.log(`%c container drop uid!`, `color: #f0f`, uid);
                            showContainer(that, uid, configsObj);
                        } else {
                            if (uid.includes(`container-title`)) {
                                // just move container
                            } else {
                                swal({
                                    title: "模块只能拖放到容器中!",
                                    text: `
                                        请先拖放容器到布局，再拖放模块!\n
                                        1 秒后自动关闭.
                                    `,
                                    icon: "warning",
                                    className: "warning-alert-style",
                                    timer: 2000,
                                    button: {
                                        text: "关闭",
                                        value: true,
                                        visible: true,
                                        closeModal: true
                                    }
                                });
                            }
                        }
                    } catch (error) {
                        console.log(`%c Sorry, showContainer some errors occurred!`, `color: #f0f`, error);
                    }
                } else {
                    // invalid value
                }
            }
        },
        sort: function () {
            let container_box = $qs(`#left-sortable-container`);
            container_box.addEventListener(`dragenter`, this.dragEnter, false);
            container_box.addEventListener(`dragover`, this.dragOver, false);
            container_box.addEventListener(`dragleave`, this.dragLeave, false);
            container_box.addEventListener(`drop`, this.drop, false);
            // sort once 暂时注释
            //sortContainers();
        },
        init: function() {
            let containers = $qsa(`[data-icon-uid*="container-data"]`);
            for (let i = 0; i < containers.length; i++) {
                containers[i].addEventListener(`dragstart`, this.dragStart, false);
            }
            // only need binding once
            this.sort();
        }
};


export default containersLoader;

export {
    containersLoader
};

