"use strict";

/**
 * @author xgqfrms
 * @license MIT
 * @description SortHandler
 *
 */
const sortContainers = () => {
    try {
        if (Sortable) {
            // containers
            let box = document.querySelector("#left-sortable-container");
            Sortable.create(box, {
                draggable: ".data-handle-container-box",
                handle: ".data-handle-container-title",
                animation: 150
            });
        } else {
            throw new Error(`Sortable.js is not imported!`);
        }
    } catch (error) {
        console.error(`sortContainers Error: \n`, error);
    }
};

const sortModules = () => {
    try {
        if (Sortable) {
            let uids = [...document.querySelectorAll(`.data-handle-container-content`)];
            uids.forEach(
                (uid) => {
                    Sortable.create(uid, {
                        group: "f10-modules", // groupe & drag handle
                        draggable: ".data-handle-container",
                        handle: ".module-drag-handle",
                        animation: 150
                    });
                }
            );
        } else {
            throw new Error(`Sortable.js is not imported!`);
        }
    } catch (error) {
        console.error(`sortModules Error: \n`, error);
    }
};

const SortHandler = ((debug = false) => {
    return {
        sortContainers,
        sortModules
    };
})();

export default SortHandler;

export {
    SortHandler,
    sortContainers,
    sortModules
};

