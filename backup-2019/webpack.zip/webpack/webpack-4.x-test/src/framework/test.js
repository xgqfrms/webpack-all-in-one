'use strict';

import "../css/common/test.css";
window.onload = () => {
    document.getElementById("test").innerHTML =  `
        <p>
            我就是我！ wwww
        </p>
    `;
    if(process.env.NODE_ENV === 'development'){
        console.log("test");
        console.log(process.env.NODE_ENV);
    }
};