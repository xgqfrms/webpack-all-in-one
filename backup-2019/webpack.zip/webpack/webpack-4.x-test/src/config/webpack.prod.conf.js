'use strict';
const path = require('path');
const CleanWebpackPlugin = require("clean-webpack-plugin");
module.exports = {
    mode: 'production',
    module: {
        rules: [
            //url-loader会将引入的图片编码，生成dataurl，把图片字符串打包到文件中，limit限制转码图片的大小，url-loader依赖file-loader
            {
                test: /\.(png|jp(e*)g|gif|svg|eot|ttf|woff|woff2|ico)$/,
                loader: "url-loader",
                options: {
                    limit: 8192,  //大于8kb交给url-file处理
                    name: "[hash]-[name].[ext]",  //图片打包的目录与文件名
                    outputPath: "imgs/",
                    publicPath: "../imgs"
                }
            },
        ],
    },
    plugins: [
        new CleanWebpackPlugin(["build"], {
            "root": path.resolve(__dirname, '../../'),
            /*将log写到consle*/
            "verbose": true,
            "dry": false,   //不要删除任何东西，用于测试
            "exclude": [] //排除不删除的目录
        }),
    ]
};

