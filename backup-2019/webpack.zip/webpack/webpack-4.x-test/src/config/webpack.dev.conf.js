'use strict';
const path = require('path');
module.exports = {
    mode: 'development',
    module: {
        rules: [
            //url-loader会将引入的图片编码，生成dataurl，把图片字符串打包到文件中，limit限制转码图片的大小，url-loader依赖file-loader
            {
                test: /\.(png|jp(e*)g|gif|svg|eot|ttf|woff|woff2|ico)$/,
                loader: "url-loader",
                options: {
                    limit: 1024,  //大于1kb交给url-file处理
                    name: "[hash]-[name].[ext]",  //图片打包的目录与文件名
                    outputPath: "imgs/",    //生成文件的目录
                    publicPath: "../imgs"  //打包文件中引用的文件路径前缀
                }
            },

        ],
    },
    plugins: [

    ],
    devServer: {
        contentBase: "build",
        compress: true,
        port: 8080
    }
};

