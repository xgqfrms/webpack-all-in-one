'use strict';

const path = require('path');
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const productionConfig = require("./webpack.prod.conf.js");
const delevopmentConfig = require("./webpack.dev.conf.js");

const merge = require('webpack-merge');

const entryConfig = require("./html.json");

if(process.env.NODE_ENV === "production"){
    console.log(`we are in production mode,packaging...`);
}else {
    console.log(`we are in development mode,packaging...`);
}

var entrys = {};
var htmlPlugins = [];

htmlPlugins.push( new ExtractTextPlugin({
    filename: (getPath) => {
        return getPath("css/[name].min.css");
    }
}));
htmlPlugins.push(
    new CopyWebpackPlugin([
        {
            from: "./src/templates",
            to: "./templates/",
            ignore: ["*.md"]
        },
    ]),
);
entryConfig.entry.forEach((item, i)=>{
    entrys[item] = `./src/framework/${item}.js`;
    let html = new HtmlWebpackPlugin({
        filename: path.resolve(__dirname, `../../build/pages/${item}.html`),
        template: path.resolve(__dirname, `../pages/${item}.html`),
        inject: 'body', //脚本在body后面引入
        chunks: [item],
        hash: true   //引入文件加hash值参数
    });
    htmlPlugins.push(html);
});

const generateConfig = {
    entry: entrys,
    output: {
        path: path.resolve(__dirname, '../../build'),  //publicPath设置资源的绝对路径
        filename: "js/[name].min.js"                 //name和实体类的名字对应
    },
    resolve: {
        extensions: [
            ".js",
            ".jsx",
            ".tsx",
            ".scss",
            ".sass",
            ".css"
        ]
    },
    module: {
        rules: [
            {
                test: /\.(js|jsx|tsx)$/,
                exclude: /(node_modules|bower_components)/,
                use: [
                    {
                        loader: "babel-loader"
                    }
                ],
            },
            {
                test: /\.((s*)css|sass)$/,        //需要依赖node-sass编译scss文件
                use: ExtractTextPlugin.extract({
                    // publicPath: "../",
                    use: [
                        {
                            loader: "css-loader",
                            options: {
                                url: true,           //设置图片压缩
                                minimize: true,      //是否压缩
                                sourceMap: true,
                                modules: true,
                                importLoaders: 1,
                                localIdentName: "gildata_[local]"     //css重命名
                            }
                        },
                        {
                            loader: "sass-loader",
                            options: {
                                sourceMap: true
                            }
                        }
                    ],
                    fallback: "style-loader"
                })
            },
            {
                test: /\.html$/,
                use: {
                    loader: 'html-loader'
                }
            }
        ]
    },
    plugins: htmlPlugins
};

module.exports = env =>{
    let config = env === 'production' ? productionConfig : delevopmentConfig;
    return merge(config, generateConfig);
};
