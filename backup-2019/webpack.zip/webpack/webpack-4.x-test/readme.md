# 组件化平台说明
### 组件化框架环境搭建过程
##### init项目及webpack说明

    npm init   创建package.json
    npm install --save-dev webpack  //引入webpack
    npm install --save-dev webpack-cli webpack-dev-server    //开发环境服务器,webpack4+需要依赖webpack-cli
    创建配置文件webpack.config.js   package.json 默认读取的配置文件名；
    本项目的配置文件在src->config中，webpack.dev.conf.js是开发环境的配置、webpack.prod.conf.js是生成环境的配置
    webpack.base.conf.js是基础配置；
    npm install --save-dev webpack-merge  //其中需要引入webpack-merge来合并配置文件
    资源：
   [webpack](https://www.webpackjs.com/)
    
##### 引入eslint和babel

    npm install --save-dev babel-core babel-loader babel-preset-env babel-preset-es2015
    npm install --save-dev eslint eslint-plugin-react babel-eslint
    创建babel和eslint配置文件
    .babelignore .babelrc 
    .eslintignore .eslintrc
    相关参数配置可以参考官网: 
   [eslint](https://eslint.org/) [babel](https://www.babeljs.cn/docs/setup)
   
##### webpak打包配置
    npm install --save-dev url-loader file-loader  //url打包依赖
    npm install --save-dev css-loader sass-loader node-sass style-loader  //样式打包依赖
    npm install --save-dev html-loader html-webpack-plugin    //html-loader解决文件引入问题
    npm install --save-dev extract-text-webpack-plugin   //抽离css样式
    npm install --save-dev clean-webpack-plugin   //删除文件插件
    相关配置见src->config下面的文件夹
    
##### 框架目录结构
    │─componentPlatform     //项目名
        │  .babelignore     //babel配置文件
        │  .babelrc
        │  .eslintignore    //eslint配置文件
        │  .eslintrc
        │  package-lock.json
        │  package.json     //package文件
        │  readme.md        //项目说明
        ├─build            //编译打包后的文件夹(打包自动生成)
        ├─node_modules     //依赖插件库(自动生成)
        └─src            
            ├─config     //配置文件夹
            │      webpack.base.conf.js     //基础配置
            │      webpack.dev.conf.js      //开发环境配置
            │      webpack.prod.conf.js     //生成环境配置
            │      
            ├─css                          //样式文件夹
            │  ├─common                   //公共样式
            │  │      test.css
            │  │      
            │  ├─plugin                   //插件样式
            │  └─skin                     //皮肤样式
            ├─framework                    //框架脚本文件夹
            │      test.js
            │      
            ├─imgs                         //图片图标文件夹
            │  ├─icons                    //原图
            │  │      favicon.ico
            │  │      test.jpg
            │  │      
            │  └─sprites                  //精灵图
            ├─pages                        //HTML文件夹 
            │      test.html
            │      
            └─utils                        //工具类
            
 #####组件化框架开发说明
        npm install         //引入依赖
        打包命令：
        npm run build
        开发环境启动：
        npm run start
    