"use strict";

/**
 *
 * @author xgqfrms
 * @license MIT
 * @copyright xgqfrms
 *
 * @description h5-dnd.js
 * @augments
 * @example
 *
 */

// import "../libs/sortable";
// import "../libs/sortable.js";
// import * as Sortable from "../libs/sortable.js";

// import "sortable";
// import { Sortable } from "sortable";// bug
// import { Sortable } from "sortablejs";// bug
import * as Sortable from "sortablejs";

// import "../css/h5-dnd.css";


console.log(`this is h5-dnd.js!`);

// global export
// window.Sortable = Sortable;

export default Sortable;

export {
    Sortable,
};
